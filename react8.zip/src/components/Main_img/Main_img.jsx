
function Main_img( {src} ) {
    return (
        <img src={src} />
    )
}

export default Main_img;