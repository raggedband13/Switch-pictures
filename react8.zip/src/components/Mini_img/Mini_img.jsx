// import { useState } from 'react';
import './Mini_img.css'

function Mini_img( {src, isActive, toggleActive} ) {

    // const [isActive, setIsActive] = useState()

    // const toggleActive = () => {
    //     if(!isActive) {
    //         setIsActive('active')
    //     } else {
    //         setIsActive('')
    //     }
        
    // }

    return (
        <img className={'galery_img_mini ' + isActive} onClick={toggleActive} src={src} />
    )
}

export default Mini_img;