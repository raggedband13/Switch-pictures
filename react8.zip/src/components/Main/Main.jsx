import { Link, Route, Routes } from 'react-router-dom';
import Mini_img from '../Mini_img/Mini_img';
import classes from './Main.module.css'
import Main_img from '../Main_img/Main_img';

function Main() {

    
    
    const toggleActive = () => {

    }

    return (
        <div className="container">
            <div className={classes.galery}>
                <div className={classes.galery_img_max}>
                    <Routes>
                        <Route path='/' element={<Main_img src='public/img-1.jpg' />} />
                        <Route path='/2' element={<Main_img src='public/img-2.jpg' />} />
                        <Route path='/3' element={<Main_img src='public/img-3.jpg' />} />
                    </Routes>
                </div>
                <div className={classes.galery_img_small}>
                    <Link to='/'><Mini_img src='public/img-1.jpg'/></Link>
                    <Link to='/2'><Mini_img src='public/img-2.jpg'/></Link>
                    <Link to='/3'><Mini_img src='public/img-3.jpg'/></Link>
                </div>
            </div>
        </div>
    )
}

export default Main;